const crypto=require('crypto'); const {sign,cookie,json}=require('./_auth');
exports.handler=async event=>{
 if(event.httpMethod!=='POST') return json(405,{error:'Method not allowed'});
 const password=process.env.ADMIN_PASSWORD, sessionSecret=process.env.SESSION_SECRET;
 if(!password || !sessionSecret) return json(500,{error:'Server configuration error. Set ADMIN_PASSWORD and SESSION_SECRET in Netlify environment variables.'});
 let supplied=''; try{supplied=JSON.parse(event.body||'{}').password||'';}catch{}
 const a=Buffer.from(String(supplied)), b=Buffer.from(password);
 const ok=a.length===b.length && crypto.timingSafeEqual(a,b);
 if(!ok) return json(401,{error:'Incorrect password.'});
 const expires=String(Math.floor(Date.now()/1000)+60*60*8);
 return json(200,{ok:true},{'Set-Cookie':cookie(expires+'.'+sign(expires),60*60*8)});
};

const crypto = require('crypto');
const COOKIE = 'fp1976_admin';
function secret() { return process.env.SESSION_SECRET || ''; }
function sign(value) { return crypto.createHmac('sha256', secret()).update(value).digest('hex'); }
function cookieValue(event) {
  const raw = event.headers?.cookie || event.headers?.Cookie || '';
  const item = raw.split(';').map(x=>x.trim()).find(x=>x.startsWith(COOKIE+'='));
  return item ? decodeURIComponent(item.slice(COOKIE.length+1)) : '';
}
function validSession(event) {
  if (!secret()) return false;
  const token = cookieValue(event); const parts = token.split('.');
  if (parts.length !== 2) return false;
  const [expires, mac] = parts;
  if (!/^\d+$/.test(expires) || Number(expires) < Math.floor(Date.now()/1000)) return false;
  const expected = sign(expires);
  return mac.length === expected.length && crypto.timingSafeEqual(Buffer.from(mac),Buffer.from(expected));
}
function cookie(value, maxAge) { return `${COOKIE}=${encodeURIComponent(value)}; HttpOnly; Secure; SameSite=Strict; Path=/.netlify/functions; Max-Age=${maxAge}`; }
function json(statusCode, body, headers={}) { return {statusCode,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers},body:JSON.stringify(body)}; }
module.exports={COOKIE,sign,validSession,cookie,json};

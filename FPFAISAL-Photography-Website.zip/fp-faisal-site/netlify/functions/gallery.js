const {json}=require('./_auth');
exports.handler=async()=>{
 const {CLOUDINARY_CLOUD_NAME:cloud,CLOUDINARY_API_KEY:key,CLOUDINARY_API_SECRET:secret}=process.env;
 if(!cloud||!key||!secret) return json(200,{items:[]});
 try{
  const auth=Buffer.from(`${key}:${secret}`).toString('base64');
  const endpoint=`https://api.cloudinary.com/v1_1/${encodeURIComponent(cloud)}/resources/search`;
  const response=await fetch(endpoint,{method:'POST',headers:{Authorization:`Basic ${auth}`,'Content-Type':'application/json'},body:JSON.stringify({expression:'tags=fp1976',sort_by:[{created_at:'desc'}],max_results:60,with_field:['context']})});
  if(!response.ok) throw new Error('Cloudinary gallery request failed');
  const data=await response.json();
  const items=(data.resources||[]).filter(x=>x.secure_url).map(x=>({resource_type:x.resource_type,secure_url:x.secure_url,title:x.context?.custom?.title||x.public_id.split('/').pop().replace(/[_-]/g,' '),created_at:x.created_at}));
  return json(200,{items});
 }catch(error){return json(502,{error:'Gallery is temporarily unavailable.',items:[]});}
};

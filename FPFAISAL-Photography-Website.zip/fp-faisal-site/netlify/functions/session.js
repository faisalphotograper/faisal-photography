const {validSession,json}=require('./_auth');
exports.handler=async event=> validSession(event)?json(200,{ok:true}):json(401,{error:'Please sign in.'});

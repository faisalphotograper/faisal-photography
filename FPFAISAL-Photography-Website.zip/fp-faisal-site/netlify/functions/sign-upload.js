const crypto=require('crypto'); const {validSession,json}=require('./_auth');
exports.handler=async event=>{
 if(event.httpMethod!=='POST') return json(405,{error:'Method not allowed'});
 if(!validSession(event)) return json(401,{error:'Please sign in again.'});
 const {CLOUDINARY_CLOUD_NAME:cloud_name,CLOUDINARY_API_KEY:api_key,CLOUDINARY_API_SECRET:api_secret}=process.env;
 if(!cloud_name||!api_key||!api_secret) return json(500,{error:'Cloudinary is not configured in Netlify environment variables.'});
 let resource_type='image'; try{const body=JSON.parse(event.body||'{}'); if(body.resource_type==='video') resource_type='video';}catch{}
 const params={folder:'FP1976',tags:'fp1976',timestamp:Math.floor(Date.now()/1000)};
 const toSign=Object.keys(params).sort().map(k=>`${k}=${params[k]}`).join('&');
 const signature=crypto.createHash('sha1').update(toSign+api_secret).digest('hex');
 return json(200,{cloud_name,api_key,resource_type,params,signature});
};

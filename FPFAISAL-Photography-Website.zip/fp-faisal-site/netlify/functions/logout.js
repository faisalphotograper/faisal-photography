const {cookie,json}=require('./_auth');
exports.handler=async event=> event.httpMethod!=='POST'?json(405,{error:'Method not allowed'}):json(200,{ok:true},{'Set-Cookie':cookie('',0)});

(() => {
  const $ = id => document.getElementById(id);
  const loginPanel = $('login-panel'), uploadPanel = $('upload-panel');
  const loginStatus = $('login-status'), uploadStatus = $('upload-status');
  if (!loginPanel || !uploadPanel) return;
  const request = async (path, options={}) => {
    const response = await fetch('/.netlify/functions/' + path, {credentials:'same-origin', ...options, headers:{'Content-Type':'application/json', ...(options.headers||{})}});
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Request failed. Please try again.');
    return data;
  };
  const show = loggedIn => { loginPanel.hidden = loggedIn; uploadPanel.hidden = !loggedIn; };
  request('session').then(() => show(true)).catch(() => show(false));
  $('login-form').addEventListener('submit', async event => {
    event.preventDefault(); loginStatus.textContent = 'Signing in…';
    try { await request('login', {method:'POST', body:JSON.stringify({password:$('admin-password').value})}); $('admin-password').value=''; loginStatus.textContent=''; show(true); }
    catch (error) { loginStatus.textContent = error.message; }
  });
  $('logout-button').addEventListener('click', async () => { try { await request('logout',{method:'POST',body:'{}'}); } finally { show(false); } });
  $('upload-button').addEventListener('click', async () => {
    const file = $('media-file').files[0];
    if (!file) { uploadStatus.textContent = 'Please select a photo or video first.'; return; }
    if (file.size > 50 * 1024 * 1024) { uploadStatus.textContent = 'Maximum file size is 50 MB.'; return; }
    const isVideo = file.type.startsWith('video/');
    if (!isVideo && !['image/jpeg','image/png','image/webp','image/avif'].includes(file.type)) { uploadStatus.textContent = 'Please choose JPG, PNG, WEBP, AVIF or MP4/MOV.'; return; }
    const button = $('upload-button'); button.disabled = true; uploadStatus.textContent = 'Preparing secure upload…';
    try {
      const signed = await request('sign-upload',{method:'POST',body:JSON.stringify({resource_type:isVideo?'video':'image'})});
      const body = new FormData();
      Object.entries(signed.params).forEach(([key,value]) => body.append(key,String(value)));
      body.append('api_key',signed.api_key); body.append('signature',signed.signature); body.append('file',file);
      uploadStatus.textContent = 'Uploading media…';
      const cloud = await fetch(`https://api.cloudinary.com/v1_1/${signed.cloud_name}/${signed.resource_type}/upload`,{method:'POST',body});
      const result = await cloud.json(); if (!cloud.ok) throw new Error(result.error?.message || 'Cloudinary upload failed.');
      uploadStatus.textContent = 'Upload successful! Your media is now being added to the public gallery.';
      $('media-file').value='';
    } catch(error) { uploadStatus.textContent = error.message; }
    finally { button.disabled = false; }
  });
})();

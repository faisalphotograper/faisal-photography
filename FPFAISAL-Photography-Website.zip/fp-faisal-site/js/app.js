(() => {
  const menu = document.getElementById('menu-toggle');
  const nav = document.getElementById('site-nav');
  if (menu && nav) menu.addEventListener('click', () => { const open = nav.classList.toggle('open'); menu.setAttribute('aria-expanded', String(open)); });
  if (document.getElementById('year')) document.getElementById('year').textContent = new Date().getFullYear();
  document.querySelectorAll('[data-service]').forEach(link => link.addEventListener('click', () => { const select = document.querySelector('[name="service"]'); if (select) select.value = link.dataset.service; }));
  const form = document.getElementById('booking-form');
  if (form) form.addEventListener('submit', event => {
    event.preventDefault(); const d = new FormData(form);
    const message = ['Assalam-o-Alaikum, I would like to book Faisal Photography.','Name: ' + d.get('name'),'Phone: ' + d.get('phone'),'Service: ' + d.get('service'),'Event date: ' + (d.get('date') || 'Not specified'),'Details: ' + (d.get('details') || 'Not specified')].join('\n');
    window.open('https://wa.me/923319730076?text=' + encodeURIComponent(message), '_blank', 'noopener');
  });
  const grid = document.getElementById('gallery-grid');
  if (grid) fetch('/.netlify/functions/gallery').then(r => { if (!r.ok) throw new Error('Gallery unavailable'); return r.json(); }).then(async ({items=[]}) => {
    if (!items.length) {
      const fallback = await fetch('/gallery.json').then(r => r.ok ? r.json() : {items:[]}).catch(() => ({items:[]}));
      items = (fallback.items || []).map(item => ({resource_type:item.type === 'video' ? 'video' : 'image', secure_url:`https://res.cloudinary.com/fgg10278/${item.type === 'video' ? 'video' : 'image'}/upload/${item.publicId}`, title:item.title}));
    }
    grid.replaceChildren();
    if (!items.length) { grid.innerHTML = '<p class="gallery-note">New photography will appear here soon.</p>'; return; }
    items.forEach(item => {
      const card = document.createElement('article'); card.className = 'media-card';
      let media;
      if (item.resource_type === 'video') { media = document.createElement('video'); media.src = item.secure_url; media.controls = true; media.preload = 'metadata'; }
      else { media = document.createElement('img'); media.src = item.secure_url; media.alt = item.title || 'Faisal Photography'; media.loading = 'lazy'; }
      card.append(media); const caption = document.createElement('p'); caption.textContent = item.title || 'Faisal Photography'; card.append(caption); grid.append(card);
    });
  }).catch(() => { grid.innerHTML = '<p class="gallery-note">Gallery is temporarily unavailable. Please check back soon.</p>'; });
})();
